module.exports = Object.freeze({
  version: 'v2.0.1',
})
