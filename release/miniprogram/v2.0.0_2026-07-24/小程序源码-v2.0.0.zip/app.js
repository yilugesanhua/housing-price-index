const locationConfig = require('./config/location.js')

App({
  onLaunch() {
    if (locationConfig.cloudEnvId && wx.cloud) {
      wx.cloud.init({ env: locationConfig.cloudEnvId, traceUser: false })
    }
  },
  globalData: {
    trialDataMode: "bundled",
  },
})
