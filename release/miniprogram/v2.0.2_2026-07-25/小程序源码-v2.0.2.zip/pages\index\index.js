const snapshot = require('../../data/snapshot.js')
const versionConfig = require('../../config/version.js')
const locationConfig = require('../../config/location.js')
const { resolveCityId } = require('../../utils/location.js')

const LABELS = {
  metric: { mom: '环比', yoy: '同比' },
  property: { new: '新房', resale: '二手房' },
  size: { all: '全部面积', le90: '90㎡及以下', '90_144': '90–144㎡', gt144: '144㎡以上' },
  range: { 36: '近3年', 60: '近5年', 120: '近10年' },
}
const OPTIONS = {
  metric: [{ value: 'mom', label: '环比' }, { value: 'yoy', label: '同比' }],
  property: [{ value: 'new', label: '新房' }, { value: 'resale', label: '二手房' }],
  size: [{ value: 'all', label: '全部面积' }, { value: 'le90', label: '90㎡及以下' }, { value: '90_144', label: '90–144㎡' }, { value: 'gt144', label: '144㎡以上' }],
  range: [{ value: 36, label: '近3年' }, { value: 60, label: '近5年' }, { value: 120, label: '近10年' }],
}
const LOCATION_CITY_IDS = [...snapshot.cityIds].sort((left, right) => left.localeCompare(right, 'en'))
const SERIES_COLORS = ['#176c79', '#2f6fbb', '#9b5b2f']
const STORAGE_KEY = 'housing-view-state-v1'
const LOCATION_CACHE_KEY = 'housing-location-cache-v1'
const FOCUS_SOURCE_KEY = 'housing-focus-source-v1'
const DEFAULT_STATE = {
  metric: 'mom',
  propertyType: 'new',
  sizeBand: 'all',
  range: 60,
  focusCity: 'beijing',
  cities: ['beijing'],
}

function formatChange(value) {
  if (value === null || value === undefined) return '—'
  return `${value > 0 ? '+' : ''}${Number(value).toFixed(1)}%`
}

function formatIndex(value) {
  if (value === null || value === undefined) return '—'
  return Number(value).toFixed(1).replace(/\.0$/, '')
}

function formatReleaseDate(value) {
  const match = String(value || '').match(/^(\d{4})-(\d{2})-(\d{2})$/)
  return match ? `${match[1]}年${Number(match[2])}月${Number(match[3])}日` : value
}

function formatChartMonth(value) {
  const match = String(value || '').match(/^(\d{4})-(\d{2})(?:-\d{2})?$/)
  return match ? `${match[1]}年${Number(match[2])}月` : value
}

function toChartDate(month) {
  return `${month}-01`
}

function readSeries(cityId, state) {
  const code = `${state.propertyType === 'new' ? 'n' : 'r'}_${{ all: 'a', le90: 's', '90_144': 'm', gt144: 'l' }[state.sizeBand]}`
  return snapshot.series[cityId][code]
}

function valueAt(cityId, state, index) {
  return readSeries(cityId, state)[index * 4 + (state.metric === 'mom' ? 2 : 3)]
}

function indexAt(cityId, state, index) {
  return readSeries(cityId, state)[index * 4 + (state.metric === 'mom' ? 0 : 1)]
}

function tone(value) {
  return value > 0 ? 'up' : value < 0 ? 'down' : 'flat'
}

function normalizeState(candidate) {
  const state = { ...DEFAULT_STATE }
  if (candidate && ['mom', 'yoy'].includes(candidate.metric)) state.metric = candidate.metric
  if (candidate && ['new', 'resale'].includes(candidate.propertyType)) state.propertyType = candidate.propertyType
  if (candidate && ['all', 'le90', '90_144', 'gt144'].includes(candidate.sizeBand)) state.sizeBand = candidate.sizeBand
  if (candidate && [36, 60, 120].includes(Number(candidate.range))) state.range = Number(candidate.range)
  if (candidate && snapshot.cityMap[candidate.focusCity]) state.focusCity = candidate.focusCity
  if (candidate && Array.isArray(candidate.cities)) state.cities = [...new Set(candidate.cities.filter((id) => snapshot.cityMap[id]))].slice(0, 3)
  return state
}

function parseQuery(query) {
  if (!query || query.v !== '1') return null
  return {
    metric: query.metric,
    propertyType: query.type,
    sizeBand: query.size,
    range: Number(query.range),
    focusCity: query.focus,
    cities: typeof query.cities === 'string' ? query.cities.split(',') : undefined,
  }
}

function rankValues(items) {
  const sorted = [...items].sort((left, right) => {
    if (left.value === null) return 1
    if (right.value === null) return -1
    return right.value - left.value || left.cityId.localeCompare(right.cityId)
  })
  const frequency = items.reduce((map, item) => {
    if (item.value !== null && item.value !== undefined) map.set(item.value, (map.get(item.value) || 0) + 1)
    return map
  }, new Map())
  let lastValue = null
  let lastRank = 0
  return sorted.map((item, index) => {
    const rank = item.value === lastValue ? lastRank : index + 1
    lastValue = item.value
    lastRank = rank
    return { ...item, rank, tied: (frequency.get(item.value) || 0) > 1 }
  })
}

function countDirections(values) {
  return values.reduce((result, value) => {
    if (value === null || value === undefined) result.missing += 1
    else if (value > 0) result.up += 1
    else if (value < 0) result.down += 1
    else result.flat += 1
    return result
  }, { up: 0, flat: 0, down: 0, missing: 0 })
}

function buildCityOptions(state, searchText) {
  const query = searchText.trim().toLowerCase().replace(/\s+/g, '')
  const featured = new Set(snapshot.featuredCityIds)
  const ids = [...snapshot.featuredCityIds, ...snapshot.cityIds.filter((id) => !featured.has(id)).sort((left, right) => left.localeCompare(right, 'en'))]
  let previousGroup = ''
  return ids
    .filter((id) => !query || snapshot.cityMap[id].search.replace(/\s+/g, '').includes(query))
    .map((id) => {
      const group = featured.has(id) ? '常用城市' : id[0].toUpperCase()
      const item = {
        id,
        name: snapshot.cityMap[id].name,
        group,
        showGroup: group !== previousGroup,
        selected: state.cities.includes(id),
        disabled: state.cities.length >= 3 && !state.cities.includes(id),
      }
      previousGroup = group
      return item
    })
}

function reportChartError(type, error) {
  const pages = getCurrentPages()
  const page = pages[pages.length - 1]
  if (page) page.setData({ [`${type}ChartError`]: true })
  console.error(`${type} chart failed`, error)
  return null
}

function buildCumulative(state) {
  const start = Math.max(0, snapshot.months.length - state.range)
  const data = []
  const latest = []
  for (const cityId of state.cities) {
    const values = readSeries(cityId, state)
    let value = 100
    let broken = false
    snapshot.months.slice(start).forEach((month, offset) => {
      const momIndex = values[(start + offset) * 4]
      if (offset > 0) {
        if (broken || momIndex === null || momIndex === undefined) broken = true
        else value = value * momIndex / 100
      }
      data.push({ month, city: snapshot.cityMap[cityId].name, cityId, value: broken ? null : Number(value.toFixed(4)) })
    })
    const last = data.filter((item) => item.cityId === cityId).at(-1)
    latest.push({ id: cityId, name: snapshot.cityMap[cityId].name, value: last ? last.value : null, display: last && last.value !== null ? formatIndex(last.value) : '—', change: last && last.value !== null ? formatChange(last.value - 100) : '无法计算' })
  }
  return { data, latest, startMonth: snapshot.months[start] }
}

function buildExactData(state, month, cumulativeData) {
  const monthIndex = snapshot.months.indexOf(month)
  return state.cities.map((cityId) => {
    const values = readSeries(cityId, state)
    const offset = monthIndex * 4
    const cumulative = cumulativeData.find((item) => item.cityId === cityId && item.month === month)
    return {
      id: cityId,
      name: snapshot.cityMap[cityId].name,
      index: formatIndex(values[offset + (state.metric === 'mom' ? 0 : 1)]),
      change: formatChange(values[offset + (state.metric === 'mom' ? 2 : 3)]),
      cumulative: cumulative && cumulative.value !== null ? formatIndex(cumulative.value) : '—',
      releaseDate: formatReleaseDate(snapshot.releaseDates[monthIndex]),
    }
  })
}

function makeView(state, searchText = '', hiddenCityIds = []) {
  const latestIndex = snapshot.months.length - 1
  const latestValues = snapshot.cityIds.map((cityId) => ({ cityId, value: valueAt(cityId, state, latestIndex) }))
  const ranked = rankValues(latestValues.filter((item) => item.value !== null && item.value !== undefined))
  const focus = ranked.find((item) => item.cityId === state.focusCity)
  const counts = countDirections(latestValues.map((item) => item.value))
  const featuredCards = rankValues(snapshot.featuredCityIds.map((cityId) => ({ cityId, value: valueAt(cityId, state, latestIndex) })))
    .map((item) => {
      const values = snapshot.months.slice(-12).map((_, offset) => valueAt(item.cityId, state, snapshot.months.length - 12 + offset))
      return {
        id: item.cityId,
        name: snapshot.cityMap[item.cityId].name,
        rank: item.rank,
        value: formatChange(item.value),
        index: formatIndex(indexAt(item.cityId, state, latestIndex)),
        tone: tone(item.value),
        movement: item.value > 0 ? '上涨' : item.value < 0 ? '下跌' : '持平',
        sparkValues: values,
      }
    })
  const cityOptions = buildCityOptions(state, searchText)
  const focusValue = focus ? focus.value : null
  const profile = snapshot.cityMap[state.focusCity]
  const tierRanked = rankValues(latestValues.filter((item) => snapshot.cityMap[item.cityId].tier === profile.tier && item.value !== null && item.value !== undefined))
  const provinceRanked = rankValues(latestValues.filter((item) => snapshot.cityMap[item.cityId].province === profile.province && item.value !== null && item.value !== undefined))
  const tierFocus = tierRanked.find((item) => item.cityId === state.focusCity)
  const provinceFocus = provinceRanked.find((item) => item.cityId === state.focusCity)
  const marketRow = (item) => ({ id: item.cityId, rank: item.rank, name: snapshot.cityMap[item.cityId].name, value: formatChange(item.value), tone: tone(item.value), current: item.cityId === state.focusCity })
  const start = Math.max(0, snapshot.months.length - state.range)
  const breadthHistory = snapshot.months.slice(start).map((month, offset) => {
    const index = start + offset
    const result = countDirections(snapshot.cityIds.map((cityId) => valueAt(cityId, state, index)))
    return { month, ...result }
  })
  const breadthChartData = breadthHistory.flatMap((item) => [
    { month: toChartDate(item.month), direction: '上涨', count: item.up },
    { month: toChartDate(item.month), direction: '持平', count: item.flat },
    { month: toChartDate(item.month), direction: '下跌', count: item.down },
  ])
  const cumulative = buildCumulative(state)
  const exactMonths = snapshot.months.slice(start)
  const exactMonth = exactMonths[exactMonths.length - 1]
  return {
    state,
    propertyLabel: LABELS.property[state.propertyType],
    metricLabel: LABELS.metric[state.metric],
    sizeLabel: LABELS.size[state.sizeBand],
    rangeLabel: LABELS.range[state.range],
    propertyIndex: OPTIONS.property.findIndex((item) => item.value === state.propertyType),
    metricIndex: OPTIONS.metric.findIndex((item) => item.value === state.metric),
    sizeIndex: OPTIONS.size.findIndex((item) => item.value === state.sizeBand),
    rangeIndex: OPTIONS.range.findIndex((item) => item.value === state.range),
    focusCityIndex: LOCATION_CITY_IDS.indexOf(state.focusCity),
    focusCityName: snapshot.cityMap[state.focusCity].name,
    focusTone: tone(focusValue),
    focusMovement: focusValue > 0 ? '上涨' : focusValue < 0 ? '下降' : '持平',
    focusMagnitude: focusValue === null ? '—' : `${Math.abs(focusValue).toFixed(1)}%`,
    focusRank: focus ? focus.rank : '—',
    rankedCount: ranked.length,
    featuredCards,
    counts,
    selectedCities: state.cities.map((id, index) => ({ id, name: snapshot.cityMap[id].name, color: SERIES_COLORS[index], seriesIndex: index, hidden: hiddenCityIds.includes(id) })),
    cityOptions,
    market: {
      total: counts.up + counts.flat + counts.down,
      upWidth: `${counts.up / Math.max(1, counts.up + counts.flat + counts.down) * 100}%`,
      flatWidth: `${counts.flat / Math.max(1, counts.up + counts.flat + counts.down) * 100}%`,
      downWidth: `${counts.down / Math.max(1, counts.up + counts.flat + counts.down) * 100}%`,
      nationalCount: ranked.length,
      nationalRank: focus ? focus.rank : '—',
      nationalRows: ranked.map(marketRow),
      tierLabel: profile.tierLabel,
      tierCount: tierRanked.length,
      tierRank: tierFocus ? tierFocus.rank : '—',
      tierRows: tierRanked.map(marketRow),
      province: profile.province,
      provinceCount: provinceRanked.length,
      provinceRank: provinceFocus ? provinceFocus.rank : '—',
      provinceRows: provinceRanked.map(marketRow),
    },
    breadthHistory,
    breadthChartData,
    cumulativeData: cumulative.data,
    cumulativeLatest: cumulative.latest.map((item, index) => ({ ...item, color: SERIES_COLORS[index], seriesIndex: index, hidden: hiddenCityIds.includes(item.id) })),
    cumulativeStartMonth: cumulative.startMonth,
    exactMonths,
    exactMonthLabels: exactMonths.map((month) => `${month.slice(0, 4)}年${Number(month.slice(5))}月`),
    exactMonthIndex: exactMonths.length - 1,
    exactMonth,
    exactData: buildExactData(state, exactMonth, cumulative.data),
  }
}

Page({
  data: {
    datasetAsOf: snapshot.datasetAsOf,
    appVersion: versionConfig.version,
    releaseDate: formatReleaseDate(snapshot.releaseDate),
    coverageStart: snapshot.coverageStart,
    latestOfficialUrl: snapshot.latestOfficialUrl,
    focusCityNames: LOCATION_CITY_IDS.map((id) => snapshot.cityMap[id].name),
    propertyOptions: OPTIONS.property.map((item) => item.label),
    metricOptions: OPTIONS.metric.map((item) => item.label),
    sizeOptions: OPTIONS.size.map((item) => item.label),
    rangeOptions: OPTIONS.range.map((item) => item.label),
    dataNotice: '',
    pickerOpen: false,
    exactOpen: false,
    showExactData: false,
    hiddenCityIds: [],
    searchText: '',
    scrollIntoView: '',
    activeSection: 'overview',
    analysisNavFixed: false,
    trendChartError: false,
    cumulativeChartError: false,
    breadthChartError: false,
    locationStatus: 'idle',
    locatedCityId: '',
    ...makeView(DEFAULT_STATE),
    onInitChart(F2, config) {
      try {
      console.info('[chart:init] trend', { width: config.width, height: config.height })
      const chart = new F2.Chart({ ...config, padding: [28, 24, 42, 48] })
      const pages = getCurrentPages()
      const page = pages[pages.length - 1]
      chart.source(page.getTrendData(), {
        month: { type: 'timeCat', mask: 'YY-MM', tickCount: 5, range: [0, 1] },
        change: { tickCount: 5 },
      })
      chart.tooltip({
        showTitle: false,
        showCrosshairs: true,
        showItemMarker: false,
        onChange({ items }) {
          const month = items && items[0] && items[0].origin && items[0].origin.month
          if (!month || !items) return
          items.forEach((item, index) => {
            item.value = formatChange(item.origin && item.origin.change)
            if (index === 0) item.name = `${formatChartMonth(month)}涨跌幅 ${item.name}`
          })
        },
      })
      chart.legend(false)
      chart.axis('month', { label: (text) => ({ fill: '#5f6368', fontSize: 9, text }), line: { stroke: '#d8d8de' } })
      chart.axis('change', { label: (text) => ({ fill: '#5f6368', fontSize: 9, text: `${text}%` }), grid: { stroke: '#e6e6eb', lineWidth: 1 } })
      chart.guide().line({ start: ['min', 0], end: ['max', 0], style: { stroke: '#8e8e93', lineDash: [4, 4], lineWidth: 1 } })
      chart.line().position('month*change').color('city', (city) => {
        const index = page.data.state.cities.findIndex((id) => snapshot.cityMap[id].name === city)
        return SERIES_COLORS[Math.max(0, index)]
      }).shape('city', (city) => {
        const index = page.data.state.cities.findIndex((id) => snapshot.cityMap[id].name === city)
        return index > 0 ? 'dash' : 'line'
      }).size(2)
      chart.animate(false)
      chart.render()
      page.chart = chart
      return chart
      } catch (error) {
        return reportChartError('trend', error)
      }
    },
    onInitCumulativeChart(F2, config) {
      try {
      console.info('[chart:init] cumulative', { width: config.width, height: config.height })
      const chart = new F2.Chart({ ...config, padding: [28, 24, 42, 48] })
      const pages = getCurrentPages()
      const page = pages[pages.length - 1]
      chart.source(page.getCumulativeData(), {
        month: { type: 'timeCat', mask: 'YY-MM', tickCount: 5, range: [0, 1] },
        value: { tickCount: 5, formatter: formatIndex },
      })
      chart.tooltip({
        showTitle: false,
        showCrosshairs: true,
        showItemMarker: false,
        onChange({ items }) {
          const month = items && items[0] && items[0].origin && items[0].origin.month
          if (month) items[0].name = `${formatChartMonth(month)} ${items[0].name}`
        },
      })
      chart.legend(false)
      chart.axis('month', { label: (text) => ({ fill: '#5f6368', fontSize: 9, text }), line: { stroke: '#d8d8de' } })
      chart.axis('value', { label: (text) => ({ fill: '#5f6368', fontSize: 9, text }), grid: { stroke: '#e6e6eb', lineWidth: 1 } })
      chart.guide().line({ start: ['min', 100], end: ['max', 100], style: { stroke: '#8e8e93', lineDash: [4, 4], lineWidth: 1 } })
      chart.line().position('month*value').color('city', (city) => {
        const index = page.data.state.cities.findIndex((id) => snapshot.cityMap[id].name === city)
        return SERIES_COLORS[Math.max(0, index)]
      }).shape('city', (city) => {
        const index = page.data.state.cities.findIndex((id) => snapshot.cityMap[id].name === city)
        return index > 0 ? 'dash' : 'line'
      }).size(2)
      chart.animate(false)
      chart.render()
      page.cumulativeChart = chart
      return chart
      } catch (error) {
        return reportChartError('cumulative', error)
      }
    },
    onInitBreadthChart(F2, config) {
      try {
      console.info('[chart:init] breadth', { width: config.width, height: config.height })
      const chart = new F2.Chart({ ...config, padding: [28, 12, 34, 32] })
      const pages = getCurrentPages()
      const page = pages[pages.length - 1]
      chart.source(page.data.breadthChartData, {
        month: { type: 'timeCat', mask: 'YY-MM', tickCount: 5, range: [0, 1] },
        count: { min: 0, max: 70, ticks: [0, 20, 40, 60, 70], nice: false },
      })
      chart.tooltip({
        showTitle: false,
        showCrosshairs: false,
        showItemMarker: true,
        onChange({ items }) {
          const month = items && items[0] && items[0].origin && items[0].origin.month
          if (!month) return
          items[0].name = `${formatChartMonth(month)} ${items[0].name}`
        },
      })
      chart.legend(false)
      chart.axis('month', { label: (text) => ({ fill: '#5f6368', fontSize: 9, text }), line: { stroke: '#d8d8de' } })
      chart.axis('count', { label: (text) => ({ fill: '#5f6368', fontSize: 9, text }), grid: { stroke: '#e6e6eb', lineWidth: 1 } })
      chart.interval().position('month*count').color('direction', ['#c94f45', '#8e8e93', '#167d67']).adjust('stack')
      chart.animate(false)
      chart.render()
      page.breadthChart = chart
      return chart
      } catch (error) {
        return reportChartError('breadth', error)
      }
    },
  },

  onLoad(query) {
    const routeState = parseQuery(query)
    let stored = null
    let focusSource = ''
    let cachedLocation = null
    try { stored = wx.getStorageSync(STORAGE_KEY) } catch (_) {}
    try { focusSource = wx.getStorageSync(FOCUS_SOURCE_KEY) } catch (_) {}
    try { cachedLocation = wx.getStorageSync(LOCATION_CACHE_KEY) } catch (_) {}
    if (cachedLocation && snapshot.cityMap[cachedLocation.cityId] && Date.now() - Number(cachedLocation.locatedAt) < locationConfig.cacheDurationMs) {
      this.setData({ locatedCityId: cachedLocation.cityId })
    }
    this.applyState(normalizeState(routeState || stored || DEFAULT_STATE), false)
    if (!routeState && focusSource !== 'manual' && locationConfig.autoLocate && locationConfig.cloudEnvId) {
      this.locateCurrentCity({ useCache: true })
    }
    const overdue = snapshot.nextCheckDueAt && Date.now() > new Date(snapshot.nextCheckDueAt).getTime()
    if (snapshot.dataStatus !== 'current' || overdue) this.setData({ dataNotice: `当前数据可能未及时更新，请以国家统计局最新发布为准。数据截至 ${snapshot.datasetAsOf}。` })
  },

  onReady() {
    this.drawSparklines()
    wx.createSelectorQuery().select('.analysis-nav').boundingClientRect((rect) => {
      if (rect) this._analysisNavTop = rect.top
    }).exec()
  },

  onShareAppMessage() {
    const state = this.data.state
    const path = `/pages/index/index?v=1&metric=${state.metric}&type=${state.propertyType}&range=${state.range}&cities=${state.cities.join(',')}&focus=${state.focusCity}&size=${state.sizeBand}`
    return { title: `70城住宅指数 · 数据截至${snapshot.datasetAsOf}`, path }
  },

  getTrendData() {
    const state = this.data.state
    const start = Math.max(0, snapshot.months.length - state.range)
    return state.cities.filter((cityId) => !this.data.hiddenCityIds.includes(cityId)).flatMap((cityId) => snapshot.months.slice(start).map((month, offset) => ({
      month: toChartDate(month),
      city: snapshot.cityMap[cityId].name,
      change: valueAt(cityId, state, start + offset),
    })))
  },

  getCumulativeData() {
    const start = Math.max(0, snapshot.months.length - this.data.state.range)
    const visibleMonths = new Set(snapshot.months.slice(start))
    return this.data.cumulativeData
      .filter((item) => visibleMonths.has(item.month) && !this.data.hiddenCityIds.includes(item.cityId) && item.value !== null)
      .map((item) => ({ ...item, month: toChartDate(item.month) }))
  },

  drawSparklines() {
    const width = 66
    const height = 24
    this.data.featuredCards.forEach((card) => {
      const values = card.sparkValues.filter((value) => value !== null && value !== undefined)
      if (values.length < 2) return
      const min = Math.min(...values, 0)
      const max = Math.max(...values, 0)
      const spread = Math.max(max - min, 0.2)
      const ctx = wx.createCanvasContext(`spark-${card.id}`, this)
      ctx.setStrokeStyle('#176c79')
      ctx.setLineWidth(1.5)
      ctx.beginPath()
      let started = false
      card.sparkValues.forEach((value, index) => {
        if (value === null || value === undefined) { started = false; return }
        const x = index / Math.max(card.sparkValues.length - 1, 1) * width
        const y = height - 2 - (value - min) / spread * (height - 4)
        if (!started) { ctx.moveTo(x, y); started = true }
        else ctx.lineTo(x, y)
      })
      ctx.stroke()
      ctx.draw()
    })
  },

  applyState(state, persist = true) {
    const hiddenCityIds = (this.data.hiddenCityIds || []).filter((id) => state.cities.includes(id))
    this.setData({ ...makeView(state, this.data.searchText || '', hiddenCityIds), hiddenCityIds }, () => {
      this.drawSparklines()
      if (this.chart) this.chart.changeData(this.getTrendData())
      if (this.cumulativeChart) this.cumulativeChart.changeData(this.getCumulativeData())
      if (this.breadthChart) this.breadthChart.changeData(this.data.breadthChartData)
    })
    if (persist) {
      try { wx.setStorageSync(STORAGE_KEY, state) } catch (_) {}
    }
  },

  onFocusCityChange(event) {
    const focusCity = LOCATION_CITY_IDS[Number(event.detail.value)]
    this.selectFocusCity(focusCity, 'manual')
  },
  selectFocusCity(focusCity, source) {
    if (!snapshot.cityMap[focusCity]) return
    const cities = source === 'location' ? [focusCity] : [...this.data.state.cities]
    if (source !== 'location' && !cities.includes(focusCity) && cities.length < 3) cities.push(focusCity)
    if (source === 'location') this.setData({ locatedCityId: focusCity })
    this.applyState({ ...this.data.state, focusCity, cities })
    try { wx.setStorageSync(FOCUS_SOURCE_KEY, source) } catch (_) {}
  },
  locateCurrentCity(options = {}) {
    if (this.data.locationStatus === 'locating') return
    if (!locationConfig.cloudEnvId || !wx.cloud || typeof wx.cloud.callFunction !== 'function') {
      wx.showToast({ title: '定位服务待配置，可手动选城', icon: 'none' })
      return
    }

    if (options.useCache) {
      let cached = null
      try { cached = wx.getStorageSync(LOCATION_CACHE_KEY) } catch (_) {}
      if (cached && snapshot.cityMap[cached.cityId] && Date.now() - Number(cached.locatedAt) < locationConfig.cacheDurationMs) {
        this.selectFocusCity(cached.cityId, 'location')
        return
      }
    }

    this.setData({ locationStatus: 'locating' })
    wx.getFuzzyLocation({
      type: 'gcj02',
      isHighAccuracy: false,
      success: ({ latitude, longitude }) => {
        wx.cloud.callFunction({
          name: locationConfig.cloudFunctionName,
          data: { latitude, longitude },
          success: ({ result }) => {
            const cityId = resolveCityId(snapshot.cityMap, result && result.city, result && result.province)
            if (!cityId) return this.finishLocation('error', '当前位置未匹配到70城，请手动选择')
            this.selectFocusCity(cityId, 'location')
            try { wx.setStorageSync(LOCATION_CACHE_KEY, { cityId, locatedAt: Date.now() }) } catch (_) {}
            this.finishLocation('success', `已定位到${snapshot.cityMap[cityId].name}`)
          },
          fail: () => this.finishLocation('error', '定位服务暂不可用，请手动选择'),
        })
      },
      fail: (error) => {
        console.error('[location:fuzzy] getFuzzyLocation failed', error)
        this.finishLocation('error', '未能获取位置，可手动选择城市')
      },
    })
  },
  finishLocation(status, message) {
    this.setData({ locationStatus: status })
    wx.showToast({ title: message, icon: 'none' })
  },
  onPropertyChange(event) { this.applyState({ ...this.data.state, propertyType: OPTIONS.property[Number(event.detail.value)].value }) },
  onMetricChange(event) { this.applyState({ ...this.data.state, metric: OPTIONS.metric[Number(event.detail.value)].value }) },
  onSizeChange(event) { this.applyState({ ...this.data.state, sizeBand: OPTIONS.size[Number(event.detail.value)].value }) },
  onRangeChange(event) { this.applyState({ ...this.data.state, range: OPTIONS.range[Number(event.detail.value)].value }) },
  resetFilters() { this.applyState({ ...this.data.state, metric: DEFAULT_STATE.metric, propertyType: DEFAULT_STATE.propertyType, sizeBand: DEFAULT_STATE.sizeBand, range: DEFAULT_STATE.range }) },
  jumpTo(event) {
    const target = event.currentTarget.dataset.target
    this.setData({ activeSection: target })
    wx.pageScrollTo({ selector: `#${target}`, offsetTop: -110, duration: 260 })
  },
  toggleLegend(event) {
    const id = event.currentTarget.dataset.id
    const hidden = [...this.data.hiddenCityIds]
    const index = hidden.indexOf(id)
    if (index >= 0) hidden.splice(index, 1)
    else {
      if (hidden.length >= this.data.state.cities.length - 1) return wx.showToast({ title: '至少保留一条趋势线', icon: 'none' })
      hidden.push(id)
    }
    this.setData({ hiddenCityIds: hidden, selectedCities: this.data.selectedCities.map((city) => ({ ...city, hidden: hidden.includes(city.id) })) }, () => {
      if (this.chart) this.chart.changeData(this.getTrendData())
      if (this.cumulativeChart) this.cumulativeChart.changeData(this.getCumulativeData())
    })
  },
  toggleExact() { this.setData({ exactOpen: !this.data.exactOpen }) },
  onExactMonthChange(event) {
    const exactMonthIndex = Number(event.detail.value)
    const exactMonth = this.data.exactMonths[exactMonthIndex]
    this.setData({ exactMonthIndex, exactMonth, exactData: buildExactData(this.data.state, exactMonth, this.data.cumulativeData) })
  },
  openPicker() { this.setData({ pickerOpen: true }) },
  closePicker() { this.setData({ pickerOpen: false, searchText: '', cityOptions: makeView(this.data.state, '', this.data.hiddenCityIds).cityOptions }) },
  stopPropagation() {},
  onSearch(event) {
    const searchText = event.detail.value
    this.setData({ searchText, cityOptions: makeView(this.data.state, searchText, this.data.hiddenCityIds).cityOptions })
  },
  toggleCity(event) {
    const id = event.currentTarget.dataset.id
    const cities = [...this.data.state.cities]
    const index = cities.indexOf(id)
    if (index >= 0) cities.splice(index, 1)
    else if (cities.length < 3) cities.push(id)
    else return wx.showToast({ title: '最多选择3座城市', icon: 'none' })
    this.applyState({ ...this.data.state, cities })
  },
  resetCities() {
    const cityId = snapshot.cityMap[this.data.locatedCityId] ? this.data.locatedCityId : DEFAULT_STATE.focusCity
    this.applyState({ ...this.data.state, cities: [cityId] })
  },
  onPageScroll(event) {
    const shouldFixAnalysisNav = this._analysisNavTop !== undefined && event.scrollTop >= this._analysisNavTop
    if (shouldFixAnalysisNav !== this.data.analysisNavFixed) this.setData({ analysisNavFixed: shouldFixAnalysisNav })
    if (this._scrollTick) return
    this._scrollTick = setTimeout(() => {
      this._scrollTick = null
      wx.createSelectorQuery().selectAll('.section').boundingClientRect((rects) => {
        const current = rects.filter((rect) => rect.top <= 150).at(-1)
        if (current && current.id && current.id !== this.data.activeSection) this.setData({ activeSection: current.id })
      }).exec()
    }, 80)
  },
  onResize() {
    clearTimeout(this._resizeTick)
    this._resizeTick = setTimeout(() => this.resizeCharts(), 120)
  },
  resizeCharts() {
    const query = wx.createSelectorQuery()
    query.select('.chart-shell').boundingClientRect()
    query.select('.cumulative-chart').boundingClientRect()
    query.select('.history-chart').boundingClientRect()
    query.exec((rects) => {
      const charts = [this.chart, this.cumulativeChart, this.breadthChart]
      rects.forEach((rect, index) => {
        if (rect && charts[index] && typeof charts[index].changeSize === 'function') charts[index].changeSize(rect.width, rect.height)
      })
    })
  },
  onUnload() {
    clearTimeout(this._scrollTick)
    clearTimeout(this._resizeTick)
    ;[this.chart, this.cumulativeChart, this.breadthChart].forEach((chart) => {
      if (chart && typeof chart.destroy === 'function') chart.destroy()
    })
  },
  openSource() { wx.navigateTo({ url: '/pages/source/source' }) },
})
